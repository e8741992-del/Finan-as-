export default {
  async fetch(request) {
    const html = `<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no"/>
<meta name="apple-mobile-web-app-capable" content="yes"/>
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent"/>
<meta name="apple-mobile-web-app-title" content="Finanças"/>
<meta name="mobile-web-app-capable" content="yes"/>
<meta name="theme-color" content="#0f1117"/>
<title>Minhas Finanças</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:wght@300;400;500;600&display=swap');

  :root {
    --bg: #0f1117;
    --bg2: #1a1d27;
    --bg3: #22263a;
    --border: #2e3248;
    --text: #e8eaf6;
    --muted: #8b8fa8;
    --green: #00e676;
    --green-dim: #1a3d2b;
    --yellow: #ffd740;
    --yellow-dim: #3d3010;
    --red: #ff5252;
    --red-dim: #3d1010;
    --blue: #448aff;
    --purple: #b388ff;
    --accent: #00e676;
  }

  * { box-sizing: border-box; margin: 0; padding: 0; }

  body {
    font-family: 'DM Sans', sans-serif;
    background: var(--bg);
    color: var(--text);
    min-height: 100vh;
    padding-bottom: 90px;
    font-size: 15px;
  }

  /* NAV */
  nav {
    position: fixed;
    top: 0; left: 0; right: 0;
    background: var(--bg);
    border-bottom: 1px solid var(--border);
    display: flex;
    justify-content: space-around;
    padding: 10px 0 6px;
    z-index: 100;
  }

  nav button {
    background: none;
    border: none;
    color: var(--muted);
    font-family: 'DM Sans', sans-serif;
    font-size: 11px;
    font-weight: 600;
    letter-spacing: 0.05em;
    cursor: pointer;
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 4px;
    padding: 4px 12px;
    border-radius: 8px;
    transition: color 0.2s;
  }

  nav button span.icon { font-size: 20px; }
  nav button.active { color: var(--accent); }

  /* TOAST */
  #toast {
    position: fixed;
    top: 70px; left: 50%;
    transform: translateX(-50%) translateY(-20px);
    background: var(--bg3);
    border: 1px solid var(--green);
    color: var(--green);
    padding: 8px 20px;
    border-radius: 20px;
    font-size: 13px;
    font-weight: 600;
    opacity: 0;
    transition: all 0.3s;
    z-index: 200;
    white-space: nowrap;
  }
  #toast.show { opacity: 1; transform: translateX(-50%) translateY(0); }

  /* SECTIONS */
  section { display: none; padding: 70px 16px 16px; }
  section.active { display: block; }

  /* CARDS */
  .card {
    background: var(--bg2);
    border: 1px solid var(--border);
    border-radius: 16px;
    padding: 16px;
    margin-bottom: 14px;
  }

  .card-title {
    font-family: 'Syne', sans-serif;
    font-size: 22px;
    font-weight: 800;
    margin-bottom: 16px;
  }

  .info-box {
    background: var(--bg3);
    border: 1px solid var(--border);
    border-radius: 12px;
    padding: 14px;
    margin-bottom: 14px;
    color: var(--purple);
    font-size: 13px;
    line-height: 1.5;
  }

  /* FORM */
  .form-card {
    background: var(--bg2);
    border: 1px solid var(--border);
    border-radius: 16px;
    padding: 16px;
    margin-bottom: 14px;
  }

  .form-label {
    font-size: 12px;
    font-weight: 600;
    letter-spacing: 0.08em;
    color: var(--muted);
    text-transform: uppercase;
    margin-bottom: 8px;
    display: block;
  }

  input, select, textarea {
    width: 100%;
    background: var(--bg3);
    border: 1px solid var(--border);
    border-radius: 10px;
    color: var(--text);
    font-family: 'DM Sans', sans-serif;
    font-size: 16px;
    padding: 12px 14px;
    margin-bottom: 12px;
    outline: none;
    transition: border-color 0.2s;
    -webkit-appearance: none;
  }

  input:focus, select:focus { border-color: var(--accent); }
  select option { background: var(--bg3); }

  .row { display: flex; gap: 10px; }
  .row > * { flex: 1; }

  /* TOGGLE */
  .toggle-row {
    display: flex;
    align-items: center;
    gap: 12px;
    margin-bottom: 12px;
    font-size: 14px;
    color: var(--muted);
  }

  .toggle {
    position: relative;
    width: 44px;
    height: 24px;
    flex-shrink: 0;
  }

  .toggle input { opacity: 0; width: 0; height: 0; }

  .toggle-slider {
    position: absolute;
    inset: 0;
    background: var(--bg3);
    border: 1px solid var(--border);
    border-radius: 24px;
    cursor: pointer;
    transition: background 0.2s;
  }

  .toggle-slider::before {
    content: '';
    position: absolute;
    width: 18px; height: 18px;
    left: 2px; top: 2px;
    background: var(--muted);
    border-radius: 50%;
    transition: all 0.2s;
  }

  .toggle input:checked + .toggle-slider { background: var(--green-dim); border-color: var(--green); }
  .toggle input:checked + .toggle-slider::before { transform: translateX(20px); background: var(--green); }

  /* BUTTONS */
  .btn-primary {
    width: 100%;
    background: var(--accent);
    color: #0f1117;
    border: none;
    border-radius: 12px;
    padding: 14px;
    font-family: 'Syne', sans-serif;
    font-size: 15px;
    font-weight: 700;
    cursor: pointer;
    transition: opacity 0.2s;
    letter-spacing: 0.03em;
  }
  .btn-primary:active { opacity: 0.8; }

  .btn-danger {
    background: none;
    border: none;
    color: var(--red);
    font-size: 18px;
    cursor: pointer;
    padding: 4px 8px;
    border-radius: 8px;
  }

  /* STATS ROW */
  .stats-row {
    display: flex;
    gap: 10px;
    margin-bottom: 14px;
  }

  .stat-box {
    flex: 1;
    background: var(--bg2);
    border: 1px solid var(--border);
    border-radius: 12px;
    padding: 12px;
    text-align: center;
  }

  .stat-label {
    font-size: 10px;
    font-weight: 700;
    letter-spacing: 0.1em;
    color: var(--muted);
    text-transform: uppercase;
    margin-bottom: 4px;
  }

  .stat-value {
    font-family: 'Syne', sans-serif;
    font-size: 16px;
    font-weight: 700;
  }

  .green { color: var(--green); }
  .yellow { color: var(--yellow); }
  .red { color: var(--red); }
  .blue { color: var(--blue); }
  .purple { color: var(--purple); }

  /* MONTH NAV */
  .month-nav {
    background: var(--bg2);
    border: 1px solid var(--border);
    border-radius: 16px;
    padding: 16px;
    margin-bottom: 14px;
  }

  .month-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 14px;
  }

  .month-header h2 {
    font-family: 'Syne', sans-serif;
    font-size: 18px;
    font-weight: 800;
    text-transform: capitalize;
  }

  .month-btn {
    background: var(--bg3);
    border: 1px solid var(--border);
    color: var(--text);
    width: 36px; height: 36px;
    border-radius: 10px;
    font-size: 18px;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: border-color 0.2s;
  }
  .month-btn:active { border-color: var(--accent); }

  .month-grid {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
  }

  .month-chip {
    background: var(--bg3);
    border: 1px solid var(--border);
    border-radius: 20px;
    padding: 6px 14px;
    font-size: 13px;
    font-weight: 500;
    cursor: pointer;
    transition: all 0.2s;
    color: var(--muted);
  }

  .month-chip.active {
    background: var(--accent);
    border-color: var(--accent);
    color: #0f1117;
    font-weight: 700;
  }

  /* INCOME CARD */
  .income-input-wrap {
    background: var(--bg3);
    border: 1px solid var(--border);
    border-radius: 12px;
    padding: 14px;
    margin-bottom: 12px;
    display: flex;
    align-items: center;
    gap: 8px;
  }

  .income-prefix {
    font-family: 'Syne', sans-serif;
    font-size: 16px;
    color: var(--muted);
    white-space: nowrap;
  }

  .income-input-wrap input {
    border: none;
    background: none;
    padding: 0;
    margin: 0;
    font-family: 'Syne', sans-serif;
    font-size: 28px;
    font-weight: 700;
    color: var(--green);
    flex: 1;
    min-width: 0;
  }

  /* ITEM LIST */
  .item-list { display: flex; flex-direction: column; gap: 10px; }

  .item-card {
    background: var(--bg3);
    border: 1px solid var(--border);
    border-radius: 12px;
    padding: 14px;
    display: flex;
    align-items: center;
    gap: 12px;
  }

  .item-info { flex: 1; min-width: 0; }
  .item-name { font-weight: 600; font-size: 14px; margin-bottom: 2px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .item-sub { font-size: 12px; color: var(--muted); }
  .item-value { font-family: 'Syne', sans-serif; font-weight: 700; font-size: 16px; flex-shrink: 0; }

  /* PAID TOGGLE */
  .paid-toggle {
    width: 28px; height: 28px;
    border-radius: 8px;
    border: 2px solid var(--border);
    background: none;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 14px;
    flex-shrink: 0;
    transition: all 0.2s;
  }
  .paid-toggle.paid { background: var(--green-dim); border-color: var(--green); color: var(--green); }

  /* 50/30/20 */
  .rule-card {
    background: var(--bg2);
    border: 1px solid var(--border);
    border-radius: 16px;
    padding: 16px;
    margin-bottom: 14px;
  }

  .rule-title {
    font-family: 'Syne', sans-serif;
    font-size: 14px;
    font-weight: 800;
    margin-bottom: 14px;
    color: var(--muted);
    letter-spacing: 0.05em;
  }

  .rule-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 10px;
  }

  .rule-bar-wrap { flex: 1; margin: 0 12px; height: 6px; background: var(--bg3); border-radius: 3px; overflow: hidden; }
  .rule-bar { height: 100%; border-radius: 3px; transition: width 0.3s; }

  /* DEBT CARD */
  .debt-card {
    background: var(--bg3);
    border: 1px solid var(--border);
    border-radius: 12px;
    padding: 14px;
    margin-bottom: 10px;
  }

  .debt-top { display: flex; align-items: center; justify-content: space-between; margin-bottom: 10px; }
  .debt-name { font-weight: 700; font-size: 15px; }
  .debt-type { font-size: 11px; color: var(--muted); background: var(--bg); border-radius: 6px; padding: 2px 8px; }

  .progress-bar { height: 8px; background: var(--bg); border-radius: 4px; overflow: hidden; margin: 8px 0; }
  .progress-fill { height: 100%; background: var(--accent); border-radius: 4px; transition: width 0.3s; }

  .debt-stats { display: flex; justify-content: space-between; font-size: 12px; color: var(--muted); }

  /* META CARD */
  .meta-card {
    background: var(--bg3);
    border: 1px solid var(--border);
    border-radius: 12px;
    padding: 14px;
    margin-bottom: 10px;
  }

  .meta-top { display: flex; align-items: center; justify-content: space-between; margin-bottom: 6px; }
  .meta-name { font-weight: 700; font-size: 15px; }
  .meta-pct { font-family: 'Syne', sans-serif; font-weight: 800; font-size: 18px; color: var(--accent); }
  .meta-deadline { font-size: 12px; color: var(--muted); margin-bottom: 8px; }
  .meta-stats { display: flex; justify-content: space-between; font-size: 12px; color: var(--muted); margin-top: 6px; }

  /* SECTION HEADER */
  .section-title {
    font-family: 'Syne', sans-serif;
    font-size: 26px;
    font-weight: 800;
    margin-bottom: 16px;
    padding-top: 4px;
  }

  /* PARCELA BOX */
  .parcela-box {
    background: var(--bg);
    border: 1px solid var(--border);
    border-radius: 10px;
    padding: 14px;
    margin-bottom: 12px;
  }

  .parcela-title {
    font-size: 12px;
    font-weight: 700;
    letter-spacing: 0.08em;
    color: var(--muted);
    text-transform: uppercase;
    margin-bottom: 10px;
    display: flex;
    align-items: center;
    gap: 6px;
  }

  /* LIMIT BOX */
  .limit-box {
    background: var(--bg);
    border: 1px solid var(--border);
    border-radius: 10px;
    padding: 14px;
    margin-bottom: 12px;
  }

  /* EMPTY STATE */
  .empty {
    text-align: center;
    color: var(--muted);
    padding: 32px 16px;
    font-size: 14px;
  }

  /* SECTION SUBTITLE */
  .section-sub {
    font-family: 'Syne', sans-serif;
    font-size: 13px;
    font-weight: 700;
    letter-spacing: 0.08em;
    color: var(--muted);
    text-transform: uppercase;
    margin-bottom: 10px;
    margin-top: 4px;
  }

  /* HIGHLIGHT BOX */
  .highlight-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 10px 0;
    border-bottom: 1px solid var(--border);
  }
  .highlight-row:last-child { border-bottom: none; }
  .highlight-label { font-size: 13px; color: var(--muted); }
  .highlight-val { font-family: 'Syne', sans-serif; font-weight: 700; font-size: 15px; }

  /* FORM TITLE */
  .form-title {
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 0.1em;
    color: var(--muted);
    text-transform: uppercase;
    margin-bottom: 14px;
  }

  /* SCROLL FIX */
  html { scroll-behavior: smooth; }
</style>
</head>
<body>

<div id="toast">💾 Salvo!</div>

<nav>
  <button class="active" onclick="showTab('fixas')" id="nav-fixas">
    <span class="icon">📌</span>FIXAS
  </button>
  <button onclick="showTab('orcamento')" id="nav-orcamento">
    <span class="icon">💰</span>ORÇAMENTO
  </button>
  <button onclick="showTab('dividas')" id="nav-dividas">
    <span class="icon">💳</span>DÍVIDAS
  </button>
  <button onclick="showTab('metas')" id="nav-metas">
    <span class="icon">🎯</span>METAS
  </button>
</nav>

<!-- ===== FIXAS ===== -->
<section id="fixas" class="active">
  <div class="section-title">📌 Contas Fixas</div>

  <div class="info-box">
    Cadastre tudo que paga todo mês — aluguel, streaming, planos, parcelamentos. Elas aparecem automaticamente no orçamento.
  </div>

  <div class="form-card">
    <div class="form-title">ADICIONAR CONTA FIXA</div>

    <label class="form-label">Descrição</label>
    <input id="fixa-desc" type="text" placeholder="Ex: Plano de celular, Netflix..."/>

    <div class="row">
      <div>
        <label class="form-label">Valor (R$)</label>
        <input id="fixa-val" type="number" placeholder="0,00" step="0.01"/>
      </div>
      <div>
        <label class="form-label">Categoria</label>
        <select id="fixa-cat">
          <option>Moradia</option>
          <option>Assinaturas</option>
          <option>Telecomunicações</option>
          <option>Transporte</option>
          <option>Saúde</option>
          <option>Educação</option>
          <option>Parcelamento</option>
          <option>Outros</option>
        </select>
      </div>
    </div>

    <div class="toggle-row">
      <label class="toggle">
        <input type="checkbox" id="fixa-parcela-toggle" onchange="toggleParcelaForm()"/>
        <span class="toggle-slider"></span>
      </label>
      <span>É um parcelamento?</span>
    </div>

    <div id="parcela-form" style="display:none">
      <div class="parcela-box">
        <div class="parcela-title">📦 Parcelamento</div>
        <label class="form-label">Parcela atual</label>
        <input id="fixa-parcela-atual" type="number" placeholder="Ex: 1"/>
        <label class="form-label">Total de parcelas</label>
        <input id="fixa-parcela-total" type="number" placeholder="Ex: 12"/>
      </div>
    </div>

    <button class="btn-primary" onclick="addFixa()">+ Adicionar Conta Fixa</button>
  </div>

  <div class="stats-row">
    <div class="stat-box">
      <div class="stat-label">Fixas mensais</div>
      <div class="stat-value green" id="fixas-total-mensal">R$ 0</div>
    </div>
    <div class="stat-box">
      <div class="stat-label">Parcelamentos</div>
      <div class="stat-value yellow" id="fixas-total-parcela">R$ 0</div>
    </div>
    <div class="stat-box">
      <div class="stat-label">Total/mês</div>
      <div class="stat-value" id="fixas-total">R$ 0</div>
    </div>
  </div>

  <div class="section-sub">Suas Contas Fixas</div>
  <div id="fixas-list" class="item-list"></div>
</section>

<!-- ===== ORÇAMENTO ===== -->
<section id="orcamento">
  <div class="section-title">💰 Orçamento</div>

  <!-- Month Nav -->
  <div class="month-nav">
    <div class="month-header">
      <button class="month-btn" onclick="prevYear()">‹</button>
      <h2 id="month-year-label">2026</h2>
      <button class="month-btn" onclick="nextYear()">›</button>
    </div>
    <div class="month-grid" id="month-grid"></div>
  </div>

  <!-- Income -->
  <div class="card">
    <div class="form-label">Renda do Mês</div>
    <div class="income-input-wrap">
      <span class="income-prefix">R$</span>
      <input id="renda-input" type="number" placeholder="0,00" step="0.01" oninput="saveRenda()"/>
    </div>
  </div>

  <!-- Stats -->
  <div class="stats-row">
    <div class="stat-box">
      <div class="stat-label">✅ Já paguei</div>
      <div class="stat-value green" id="orc-pago">R$ 0</div>
    </div>
    <div class="stat-box">
      <div class="stat-label">⏳ Ainda falta</div>
      <div class="stat-value yellow" id="orc-falta">R$ 0</div>
    </div>
  </div>

  <div class="stats-row">
    <div class="stat-box">
      <div class="stat-label">Fixo</div>
      <div class="stat-value purple" id="orc-fixo">R$ 0</div>
    </div>
    <div class="stat-box">
      <div class="stat-label">Variável</div>
      <div class="stat-value yellow" id="orc-variavel">R$ 0</div>
    </div>
    <div class="stat-box">
      <div class="stat-label">Saldo</div>
      <div class="stat-value green" id="orc-saldo">R$ 0</div>
    </div>
  </div>

  <!-- Fixed accounts this month -->
  <div class="card" id="fixas-mes-card">
    <div class="section-sub" style="margin-bottom:12px">Contas Fixas do Mês</div>
    <div id="fixas-mes-list"></div>
  </div>

  <!-- 50/30/20 -->
  <div class="rule-card">
    <div class="rule-title">REGRA 50/30/20</div>
    <div class="rule-row">
      <span style="font-size:13px;color:var(--muted);width:120px">Necessidades (50%)</span>
      <div class="rule-bar-wrap"><div class="rule-bar" id="rule-nec" style="background:var(--green);width:0%"></div></div>
      <span class="green" style="font-size:13px;font-weight:700;width:70px;text-align:right" id="rule-nec-val">R$ 0</span>
    </div>
    <div class="rule-row">
      <span style="font-size:13px;color:var(--muted);width:120px">Lazer (30%)</span>
      <div class="rule-bar-wrap"><div class="rule-bar" id="rule-laz" style="background:var(--yellow);width:0%"></div></div>
      <span class="yellow" style="font-size:13px;font-weight:700;width:70px;text-align:right" id="rule-laz-val">R$ 0</span>
    </div>
    <div class="rule-row">
      <span style="font-size:13px;color:var(--muted);width:120px">Poupança (20%)</span>
      <div class="rule-bar-wrap"><div class="rule-bar" id="rule-pou" style="background:var(--blue);width:0%"></div></div>
      <span class="blue" style="font-size:13px;font-weight:700;width:70px;text-align:right" id="rule-pou-val">R$ 0</span>
    </div>
  </div>

  <!-- Variable expense form -->
  <div class="form-card">
    <div class="form-title">ADICIONAR GASTO VARIÁVEL</div>
    <label class="form-label">Descrição</label>
    <input id="var-desc" type="text" placeholder="Ex: Mercado, cinema..."/>

    <div class="row">
      <div>
        <label class="form-label">Valor (R$)</label>
        <input id="var-val" type="number" placeholder="0,00" step="0.01"/>
      </div>
      <div>
        <label class="form-label">Categoria</label>
        <select id="var-cat">
          <option>Moradia</option>
          <option>Alimentação</option>
          <option>Transporte</option>
          <option>Saúde</option>
          <option>Lazer</option>
          <option>Educação</option>
          <option>Outros</option>
        </select>
      </div>
    </div>

    <div class="toggle-row">
      <label class="toggle">
        <input type="checkbox" id="var-limite-toggle" onchange="toggleLimiteForm()"/>
        <span class="toggle-slider"></span>
      </label>
      <span>Tem limite pra gastar? (Feira, Gasolina...)</span>
    </div>

    <div id="limite-form" style="display:none">
      <div class="limit-box">
        <label class="form-label">Limite (R$)</label>
        <input id="var-limite" type="number" placeholder="Ex: 500,00" step="0.01"/>
      </div>
    </div>

    <button class="btn-primary" onclick="addVariavel()">+ Adicionar</button>
  </div>

  <div class="section-sub">Gastos Variáveis</div>
  <div id="variaveis-list" class="item-list"></div>
</section>

<!-- ===== DÍVIDAS ===== -->
<section id="dividas">
  <div class="section-title">💳 Dívidas</div>

  <div class="info-box">
    💡 As dívidas são contínuas — acompanhe o progresso aqui, independente do mês.
  </div>

  <div class="stats-row">
    <div class="stat-box">
      <div class="stat-label">Total</div>
      <div class="stat-value red" id="div-total">R$ 0</div>
    </div>
    <div class="stat-box">
      <div class="stat-label">Já Pago</div>
      <div class="stat-value green" id="div-pago">R$ 0</div>
    </div>
    <div class="stat-box">
      <div class="stat-label">Restante</div>
      <div class="stat-value yellow" id="div-restante">R$ 0</div>
    </div>
  </div>

  <div class="form-card">
    <div class="form-title">ADICIONAR DÍVIDA</div>
    <label class="form-label">Nome</label>
    <input id="div-nome" type="text" placeholder="Ex: Cartão Nubank..."/>

    <label class="form-label">Tipo</label>
    <select id="div-tipo">
      <option>Cartão de Crédito</option>
      <option>Empréstimo</option>
      <option>Financiamento</option>
      <option>Cheque Especial</option>
      <option>Outro</option>
    </select>

    <div class="row">
      <div>
        <label class="form-label">Total (R$)</label>
        <input id="div-total-val" type="number" placeholder="0,00" step="0.01"/>
      </div>
      <div>
        <label class="form-label">Já pago (R$)</label>
        <input id="div-pago-val" type="number" placeholder="0,00" step="0.01"/>
      </div>
    </div>

    <label class="form-label">Juros % a.m.</label>
    <input id="div-juros" type="number" placeholder="Ex: 2.5" step="0.01"/>

    <button class="btn-primary" onclick="addDivida()">+ Adicionar Dívida</button>
  </div>

  <div class="section-sub">Suas Dívidas <span style="font-size:10px;color:var(--muted)">(maior juros primeiro)</span></div>
  <div id="dividas-list"></div>
</section>

<!-- ===== METAS ===== -->
<section id="metas">
  <div class="section-title">🎯 Metas</div>

  <div class="info-box">
    💡 Veja quanto guardar por mês para atingir cada objetivo.
  </div>

  <div class="form-card">
    <div class="form-title">NOVA META</div>
    <label class="form-label">Nome da meta</label>
    <input id="meta-nome" type="text" placeholder="Ex: Viagem, Reserva de emergência..."/>

    <div class="row">
      <div>
        <label class="form-label">Objetivo (R$)</label>
        <input id="meta-obj" type="number" placeholder="0,00" step="0.01"/>
      </div>
      <div>
        <label class="form-label">Já guardado (R$)</label>
        <input id="meta-guard" type="number" placeholder="0,00" step="0.01"/>
      </div>
    </div>

    <label class="form-label">Prazo</label>
    <input id="meta-prazo" type="month" min="2026-06"/>

    <button class="btn-primary" onclick="addMeta()">+ Criar Meta</button>
  </div>

  <div id="metas-list"></div>
</section>

<script>
// ====== DATA ======
const START_YEAR = 2026;
const START_MONTH = 5; // 0-indexed: 5 = June

function load(key, def) {
  try { const v = localStorage.getItem(key); return v ? JSON.parse(v) : def; } catch { return def; }
}
function save(key, val) {
  localStorage.setItem(key, JSON.stringify(val));
  showToast();
}

function showToast() {
  const t = document.getElementById('toast');
  t.classList.add('show');
  clearTimeout(window._toastTimer);
  window._toastTimer = setTimeout(() => t.classList.remove('show'), 1800);
}

// ====== CURRENCY ======
function fmt(v) {
  return 'R$ ' + Number(v || 0).toLocaleString('pt-BR', {minimumFractionDigits: 2, maximumFractionDigits: 2});
}

// ====== TABS ======
function showTab(id) {
  document.querySelectorAll('section').forEach(s => s.classList.remove('active'));
  document.querySelectorAll('nav button').forEach(b => b.classList.remove('active'));
  document.getElementById(id).classList.add('active');
  document.getElementById('nav-' + id).classList.add('active');
  if (id === 'orcamento') renderOrcamento();
  if (id === 'dividas') renderDividas();
  if (id === 'metas') renderMetas();
}

// ====== MONTH STATE ======
let currentYear = 2026;
let currentMonth = 5; // June

function monthKey() { return currentYear + '-' + String(currentMonth + 1).padStart(2, '0'); }

const MONTH_NAMES = ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];
const MONTH_SHORT = ['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez'];

function renderMonthGrid() {
  document.getElementById('month-year-label').textContent = currentYear;
  const grid = document.getElementById('month-grid');
  grid.innerHTML = '';

  // Show months from June 2026 onwards for current year
  let startM = 0;
  if (currentYear === START_YEAR) startM = START_MONTH;

  for (let m = startM; m < 12; m++) {
    const chip = document.createElement('button');
    chip.className = 'month-chip' + (m === currentMonth && currentYear === currentYear ? ' active' : '');
    // Re-check
    chip.className = 'month-chip' + (m === currentMonth ? ' active' : '');
    chip.textContent = MONTH_SHORT[m] + ' ' + currentYear;
    const mm = m;
    chip.onclick = () => { currentMonth = mm; renderMonthGrid(); renderOrcamento(); };
    grid.appendChild(chip);
  }
}

function prevYear() {
  if (currentYear <= START_YEAR) return;
  currentYear--;
  if (currentYear === START_YEAR && currentMonth < START_MONTH) currentMonth = START_MONTH;
  renderMonthGrid();
  renderOrcamento();
}

function nextYear() {
  currentYear++;
  renderMonthGrid();
  renderOrcamento();
}

// ====== FIXAS ======
function getFixas() { return load('fixas', []); }
function saveFixas(f) { save('fixas', f); }

function toggleParcelaForm() {
  const on = document.getElementById('fixa-parcela-toggle').checked;
  document.getElementById('parcela-form').style.display = on ? 'block' : 'none';
  if (on) document.getElementById('fixa-cat').value = 'Parcelamento';
}

function addFixa() {
  const desc = document.getElementById('fixa-desc').value.trim();
  const val = parseFloat(document.getElementById('fixa-val').value);
  const cat = document.getElementById('fixa-cat').value;
  const isParcela = document.getElementById('fixa-parcela-toggle').checked;

  if (!desc || isNaN(val) || val <= 0) { alert('Preencha descrição e valor.'); return; }

  const item = { id: Date.now(), desc, val, cat, isParcela };
  if (isParcela) {
    item.parcelaAtual = parseInt(document.getElementById('fixa-parcela-atual').value) || 1;
    item.parcelaTotal = parseInt(document.getElementById('fixa-parcela-total').value) || 1;
  }

  const fixas = getFixas();
  fixas.push(item);
  saveFixas(fixas);

  // Reset
  document.getElementById('fixa-desc').value = '';
  document.getElementById('fixa-val').value = '';
  document.getElementById('fixa-cat').value = 'Moradia';
  document.getElementById('fixa-parcela-toggle').checked = false;
  document.getElementById('parcela-form').style.display = 'none';
  document.getElementById('fixa-parcela-atual').value = '';
  document.getElementById('fixa-parcela-total').value = '';

  renderFixas();
}

function deleteFixa(id) {
  if (!confirm('Remover esta conta fixa?')) return;
  const fixas = getFixas().filter(f => f.id !== id);
  saveFixas(fixas);
  renderFixas();
}

function renderFixas() {
  const fixas = getFixas();
  const list = document.getElementById('fixas-list');

  let mensalTotal = 0, parcelaTotal = 0;

  if (fixas.length === 0) {
    list.innerHTML = '<div class="empty">Nenhuma conta fixa cadastrada ainda. 📌</div>';
  } else {
    list.innerHTML = '';
    fixas.forEach(f => {
      if (f.isParcela) parcelaTotal += f.val;
      else mensalTotal += f.val;

      const el = document.createElement('div');
      el.className = 'item-card';
      el.innerHTML = \`
        <div class="item-info">
          <div class="item-name">\${f.desc}</div>
          <div class="item-sub">\${f.cat}\${f.isParcela ? \` · \${f.parcelaAtual}/\${f.parcelaTotal}x\` : ''}</div>
        </div>
        <div class="item-value \${f.isParcela ? 'yellow' : 'green'}">\${fmt(f.val)}</div>
        <button class="btn-danger" onclick="deleteFixa(\${f.id})">×</button>
      \`;
      list.appendChild(el);
    });
  }

  document.getElementById('fixas-total-mensal').textContent = fmt(mensalTotal);
  document.getElementById('fixas-total-parcela').textContent = fmt(parcelaTotal);
  document.getElementById('fixas-total').textContent = fmt(mensalTotal + parcelaTotal);
}

// ====== ORÇAMENTO ======
function getOrcData() { return load('orc_' + monthKey(), { renda: 0, variaveis: [], pagos: {} }); }
function saveOrcData(d) { save('orc_' + monthKey(), d); }

function saveRenda() {
  const d = getOrcData();
  d.renda = parseFloat(document.getElementById('renda-input').value) || 0;
  saveOrcData(d);
  updateOrcStats();
}

function togglePago(id) {
  const d = getOrcData();
  d.pagos = d.pagos || {};
  d.pagos[id] = !d.pagos[id];
  saveOrcData(d);
  renderOrcamento();
}

function toggleLimiteForm() {
  const on = document.getElementById('var-limite-toggle').checked;
  document.getElementById('limite-form').style.display = on ? 'block' : 'none';
}

function addVariavel() {
  const desc = document.getElementById('var-desc').value.trim();
  const val = parseFloat(document.getElementById('var-val').value);
  const cat = document.getElementById('var-cat').value;
  const hasLimite = document.getElementById('var-limite-toggle').checked;
  const limite = hasLimite ? (parseFloat(document.getElementById('var-limite').value) || 0) : null;

  if (!desc || isNaN(val) || val <= 0) { alert('Preencha descrição e valor.'); return; }

  const d = getOrcData();
  d.variaveis = d.variaveis || [];
  d.variaveis.push({ id: Date.now(), desc, val, cat, limite });
  saveOrcData(d);

  document.getElementById('var-desc').value = '';
  document.getElementById('var-val').value = '';
  document.getElementById('var-cat').value = 'Alimentação';
  document.getElementById('var-limite-toggle').checked = false;
  document.getElementById('limite-form').style.display = 'none';
  document.getElementById('var-limite').value = '';

  renderOrcamento();
}

function deleteVariavel(id) {
  const d = getOrcData();
  d.variaveis = (d.variaveis || []).filter(v => v.id !== id);
  saveOrcData(d);
  renderOrcamento();
}

function renderOrcamento() {
  renderMonthGrid();

  const d = getOrcData();
  const renda = d.renda || 0;
  const pagos = d.pagos || {};
  const fixas = getFixas();

  // Renda
  document.getElementById('renda-input').value = renda || '';

  // Fixed costs
  const fixasTotal = fixas.reduce((s, f) => s + f.val, 0);
  let fixasPago = 0, fixasFalta = 0;
  const fixasList = document.getElementById('fixas-mes-list');
  fixasList.innerHTML = '';

  if (fixas.length === 0) {
    fixasList.innerHTML = '<div class="empty" style="padding:16px">Nenhuma conta fixa cadastrada.</div>';
  } else {
    fixas.forEach(f => {
      const pago = !!pagos['fixa_' + f.id];
      if (pago) fixasPago += f.val;
      else fixasFalta += f.val;

      const el = document.createElement('div');
      el.className = 'highlight-row';
      el.innerHTML = \`
        <button class="paid-toggle \${pago ? 'paid' : ''}" onclick="togglePago('fixa_\${f.id}')">
          \${pago ? '✓' : ''}
        </button>
        <div style="flex:1;margin:0 10px">
          <div style="font-size:14px;font-weight:600">\${f.desc}</div>
          <div style="font-size:11px;color:var(--muted)">\${f.cat}</div>
        </div>
        <div class="highlight-val \${pago ? 'green' : 'yellow'}">\${fmt(f.val)}</div>
      \`;
      fixasList.appendChild(el);
    });
  }

  // Variable costs
  const variaveis = d.variaveis || [];
  const varTotal = variaveis.reduce((s, v) => s + v.val, 0);
  const saldo = renda - fixasTotal - varTotal;

  document.getElementById('orc-pago').textContent = fmt(fixasPago);
  document.getElementById('orc-falta').textContent = fmt(fixasFalta);
  document.getElementById('orc-fixo').textContent = fmt(fixasTotal);
  document.getElementById('orc-variavel').textContent = fmt(varTotal);

  const saldoEl = document.getElementById('orc-saldo');
  saldoEl.textContent = fmt(saldo);
  saldoEl.className = 'stat-value ' + (saldo >= 0 ? 'green' : 'red');

  // 50/30/20
  const nec = renda * 0.5;
  const laz = renda * 0.3;
  const pou = renda * 0.2;
  document.getElementById('rule-nec-val').textContent = fmt(nec);
  document.getElementById('rule-laz-val').textContent = fmt(laz);
  document.getElementById('rule-pou-val').textContent = fmt(pou);
  const necPct = renda > 0 ? Math.min(100, (fixasTotal / nec) * 100) : 0;
  const lazPct = renda > 0 ? Math.min(100, (varTotal / laz) * 100) : 0;
  const pouPct = renda > 0 ? Math.min(100, (saldo / pou) * 100) : 0;
  document.getElementById('rule-nec').style.width = necPct + '%';
  document.getElementById('rule-laz').style.width = lazPct + '%';
  document.getElementById('rule-pou').style.width = pouPct + '%';

  // Variaveis list
  const vList = document.getElementById('variaveis-list');
  if (variaveis.length === 0) {
    vList.innerHTML = '<div class="empty">Nenhum gasto variável este mês.</div>';
  } else {
    vList.innerHTML = '';
    variaveis.forEach(v => {
      const el = document.createElement('div');
      el.className = 'item-card';
      let subText = v.cat;
      if (v.limite) subText += \` · Limite: \${fmt(v.limite)}\`;
      el.innerHTML = \`
        <div class="item-info">
          <div class="item-name">\${v.desc}</div>
          <div class="item-sub">\${subText}</div>
        </div>
        <div class="item-value yellow">\${fmt(v.val)}</div>
        <button class="btn-danger" onclick="deleteVariavel(\${v.id})">×</button>
      \`;
      vList.appendChild(el);
    });
  }
}

function updateOrcStats() { renderOrcamento(); }

// ====== DÍVIDAS ======
function getDividas() { return load('dividas', []); }
function saveDividas(d) { save('dividas', d); }

function addDivida() {
  const nome = document.getElementById('div-nome').value.trim();
  const tipo = document.getElementById('div-tipo').value;
  const total = parseFloat(document.getElementById('div-total-val').value) || 0;
  const pago = parseFloat(document.getElementById('div-pago-val').value) || 0;
  const juros = parseFloat(document.getElementById('div-juros').value) || 0;

  if (!nome || total <= 0) { alert('Preencha nome e valor total.'); return; }

  const dividas = getDividas();
  dividas.push({ id: Date.now(), nome, tipo, total, pago, juros });
  saveDividas(dividas);

  document.getElementById('div-nome').value = '';
  document.getElementById('div-total-val').value = '';
  document.getElementById('div-pago-val').value = '';
  document.getElementById('div-juros').value = '';

  renderDividas();
}

function deleteDivida(id) {
  if (!confirm('Remover esta dívida?')) return;
  const dividas = getDividas().filter(d => d.id !== id);
  saveDividas(dividas);
  renderDividas();
}

function renderDividas() {
  const dividas = getDividas().sort((a, b) => b.juros - a.juros);
  const list = document.getElementById('dividas-list');

  const totalT = dividas.reduce((s, d) => s + d.total, 0);
  const totalP = dividas.reduce((s, d) => s + d.pago, 0);
  const totalR = totalT - totalP;

  document.getElementById('div-total').textContent = fmt(totalT);
  document.getElementById('div-pago').textContent = fmt(totalP);
  document.getElementById('div-restante').textContent = fmt(totalR);

  if (dividas.length === 0) {
    list.innerHTML = '<div class="empty">Nenhuma dívida cadastrada. 🎉</div>';
    return;
  }

  list.innerHTML = '';
  dividas.forEach(d => {
    const pct = d.total > 0 ? Math.min(100, (d.pago / d.total) * 100) : 0;
    const restante = Math.max(0, d.total - d.pago);
    const el = document.createElement('div');
    el.className = 'debt-card';
    el.innerHTML = \`
      <div class="debt-top">
        <div>
          <div class="debt-name">\${d.nome}</div>
          <span class="debt-type">\${d.tipo}</span>
        </div>
        <button class="btn-danger" onclick="deleteDivida(\${d.id})">×</button>
      </div>
      <div class="progress-bar"><div class="progress-fill" style="width:\${pct}%"></div></div>
      <div class="debt-stats">
        <span>Pago: <span style="color:var(--green);font-weight:700">\${fmt(d.pago)}</span></span>
        <span>\${pct.toFixed(0)}%</span>
        <span>Falta: <span style="color:var(--yellow);font-weight:700">\${fmt(restante)}</span></span>
      </div>
      \${d.juros > 0 ? \`<div style="margin-top:8px;font-size:12px;color:var(--red)">Juros: \${d.juros}% a.m.</div>\` : ''}
    \`;
    list.appendChild(el);
  });
}

// ====== METAS ======
function getMetas() { return load('metas', []); }
function saveMetas(m) { save('metas', m); }

function addMeta() {
  const nome = document.getElementById('meta-nome').value.trim();
  const obj = parseFloat(document.getElementById('meta-obj').value) || 0;
  const guard = parseFloat(document.getElementById('meta-guard').value) || 0;
  const prazo = document.getElementById('meta-prazo').value;

  if (!nome || obj <= 0) { alert('Preencha nome e objetivo.'); return; }

  const metas = getMetas();
  metas.push({ id: Date.now(), nome, obj, guard, prazo });
  saveMetas(metas);

  document.getElementById('meta-nome').value = '';
  document.getElementById('meta-obj').value = '';
  document.getElementById('meta-guard').value = '';
  document.getElementById('meta-prazo').value = '';

  renderMetas();
}

function deleteMeta(id) {
  if (!confirm('Remover esta meta?')) return;
  const metas = getMetas().filter(m => m.id !== id);
  saveMetas(metas);
  renderMetas();
}

function renderMetas() {
  const metas = getMetas();
  const list = document.getElementById('metas-list');

  if (metas.length === 0) {
    list.innerHTML = '<div class="empty">Nenhuma meta criada ainda. 🎯</div>';
    return;
  }

  list.innerHTML = '';
  metas.forEach(m => {
    const pct = m.obj > 0 ? Math.min(100, (m.guard / m.obj) * 100) : 0;
    const falta = Math.max(0, m.obj - m.guard);

    let prazoText = '';
    let porMes = '';
    if (m.prazo) {
      const [y, mo] = m.prazo.split('-').map(Number);
      const now = new Date(2026, 5, 1); // June 2026
      const deadline = new Date(y, mo - 1, 1);
      const months = Math.max(1, (deadline.getFullYear() - now.getFullYear()) * 12 + (deadline.getMonth() - now.getMonth()));
      const d = new Date(y, mo - 1);
      prazoText = \`Prazo: \${d.toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' })}\`;
      porMes = falta > 0 ? \` · Guardar \${fmt(falta / months)}/mês\` : '';
    }

    const el = document.createElement('div');
    el.className = 'meta-card';
    el.innerHTML = \`
      <div class="meta-top">
        <div class="meta-name">\${m.nome}</div>
        <div style="display:flex;align-items:center;gap:8px">
          <span class="meta-pct">\${pct.toFixed(0)}%</span>
          <button class="btn-danger" onclick="deleteMeta(\${m.id})">×</button>
        </div>
      </div>
      \${prazoText ? \`<div class="meta-deadline">\${prazoText}\${porMes}</div>\` : ''}
      <div class="progress-bar"><div class="progress-fill" style="width:\${pct}%"></div></div>
      <div class="meta-stats">
        <span>Guardado: <span style="color:var(--green);font-weight:700">\${fmt(m.guard)}</span></span>
        <span>Meta: <span style="color:var(--text);font-weight:700">\${fmt(m.obj)}</span></span>
      </div>
    \`;
    list.appendChild(el);
  });
}

// ====== INIT ======
renderFixas();
renderMonthGrid();
renderOrcamento();
</script>
</body>
</html>
`;
    return new Response(html, {
      headers: { 'Content-Type': 'text/html;charset=UTF-8' }
    });
  }
};